manhattan_blocks <- function(traits)
{
  ### single trait manhattans with significant blocks overlay
  # library(tidyverse)
  # library(data.table)
  # library(RColorBrewer)
  # library(ggplot2)
  # library(ggpubr)

  colours<-rep(c(RColorBrewer::brewer.pal(8,"Dark2"))[-7],3)


  sig.list<-read.table(get_project_dir(subdir = "Tables/Blocks",file = "sigsnips_to_genomeblocks.txt"),header=T)
  genemap<-read.table(get_project_dir(subdir = "Tables/Blocks",file = "condensed_genome_blocks.txt"),header=T)
  colocate<-read.table(get_project_dir(subdir = "Tables/Blocks",file = "colocate_table.txt"))

  colocate<- colocate |> dplyr::group_by(chromosome) |> dplyr::mutate(region_col=colours[as.numeric(factor(rank(match(region,levels(region)))))])

  ### name haplotype blocks and list snps per haplotype block
  blocks<-data.table::fread(get_blocks()[1])
  blocks$Chr_num<- as.integer(gsub("Ha412HOChr","",blocks$CHR))
  blocks<- blocks |> dplyr::group_by(Chr_num) |> dplyr::mutate(hapID = paste(Chr_num,c(1:length(Chr_num)),sep="_"))
  snps<-strsplit(blocks$SNPS,split="|",fixed=T)
  big.list<-unlist(snps)
  big.list<-data.table::data.table(SNP=big.list)
  big.list$hapID<-c(rep(blocks$hapID, blocks$NSNPS))
  rm(snps)

  ### qd solution singletons
  all.snps<-data.table::fread(get_blocks()[2], header=F)
  names(all.snps)[1:4]<-c("chr","rs","V3","ps")
  all.snps$V3<-NULL

  missing.snps<-all.snps[!all.snps$rs%in%big.list$SNP,]
  missing.snps$Chr_num<- as.integer(gsub("Ha412HOChr","",missing.snps$chr))
  missing.snps<- missing.snps |> dplyr::group_by(Chr_num) |> dplyr::mutate(hapID=paste(Chr_num,"_single",match(rs,unique(rs)),sep=""))
  missing.snps<-missing.snps[,c(2,5)]
  names(missing.snps)<-c("SNP","hapID")

  big.list<-rbind(big.list,missing.snps)

  ###setup the data

  # envs<-as.character(read.table("environments_to_run.txt")[,1])
  # traits<- as.character(unlist(as.list(read.csv(paste0("data/",trait_filename) , nrows=1, header = F)[-1])))
  envs <- ""
  q <- 1


  suggthresh<-0.001 ## draw line at "suggestive" SNPs (threshold fraction of snips are above the blue line)

  #### loop over every trait and then over every environment to plot the manhattans
  #### loops within loops (insert Dune reference here)

  for (i in 1:length(traits)){
    # for (q in 1:length(envs))
    {

      # if (!paste(traits[i],"_",envs[q],".assoc.txt",sep="")%in%dir("Tables/Assoc_files/")) {
      #   print("Phenotype does not exist or not run through gemma")
      #   plot<-plot(c(1:10,1:10)~c(1:10,10:1))
      #   assign(envs[q],plot)
      #   next
      # } ### deal with missing association file
      results <- get_gwas(traits[i])
      results$GWAS$hapID <- snpInfo$hapID
      # pdf(paste("Plots/Manhattans/single_env/",traits[i],"-",envs[q],"_ManhattanPlot.pdf",sep=""),height=5.5,width=7.5)
      label<-paste(traits[i])
      # print(label)
      # snips<-fread(paste("Tables/Assoc_files/",paste(traits[i],envs[q],sep="_"),".assoc.txt",sep=""))
      # snips$CHR<- as.integer(gsub("Ha412HOChr","",snips$chr))

      # snips<-merge(snips,big.list,by.x="rs",by.y="SNP")
      # snips$ps <- as.numeric(snips$ps)

      # trait.blocks<-colocate[colocate$trait_env==paste(traits[i],envs[q],sep="_"),]
      trait.blocks<-colocate[colocate$trait_env==paste(traits[i],envs[q],sep="_"),]


      tmpcutoff <- -log10(as.data.frame(quantile(results$GWAS$pval,as.numeric(as.character(suggthresh))))[1,1])
      ##### bit that makes the plot

      spacer<-30000000
      results$GWAS$position <- as.numeric(results$GWAS$position)

      chr_cumsum<- results$GWAS |> ## code from https://www.r-graph-gallery.com/wp-content/uploads/2018/02/Manhattan_plot_in_R.html
        dplyr::group_by(chromosome) |>
        dplyr::summarise(chr_len=max(position)) |>  # Compute chromosome size
        dplyr::mutate(tot=cumsum(chr_len)-chr_len) |> # Calculate cumulative position of each chromosome
        dplyr::select(-chr_len)

      chr_cumsum$tot <- chr_cumsum$tot+c((spacer*chr_cumsum$chromosome)-spacer)

      results$GWAS <- merge(results$GWAS, chr_cumsum, by="chromosome")
      results$GWAS$BPcum<-results$GWAS$position+results$GWAS$tot

      results$GWAS<-data.table::data.table(results$GWAS)

      genome.size<-max(results$GWAS$BPcum)

      axisdf <- results$GWAS |> dplyr::group_by(chromosome) |> dplyr::summarize(center=( max(BPcum) + min(BPcum) ) / 2 ) ## set chromosome label position

      ytop <- -log10(min(results$GWAS$pval))
      if (ytop > 10){ ytop = ytop+2} else { ytop = 10}

      results$GWAS<-results$GWAS |> dplyr::filter(-log10(pval)>1)


      highlights<-results$GWAS[results$GWAS$hapID%in%trait.blocks$hapID,] # snips to highlight for their blocks

      highlights<-merge(highlights,trait.blocks,by="hapID",all.x=T)
      # highlights<-highlights |> dplyr::group_by(chromosome) |> mutate(region_col=colours[as.numeric(factor(rank(match(region,levels(region)))))])
      highlights$region_col<-colocate$region_col[match(highlights$region,colocate$region)]

      multcomp <- 19918

      plot<-ggplot2::ggplot(data=results$GWAS, ggplot2::aes(x=BPcum, y=-log10(pval),color=as.factor(chromosome)))+
        ggplot2::geom_point(size=0.4)+ggplot2::scale_color_manual(values=rep(c("grey75",RColorBrewer::brewer.pal("Blues",n=9)[3]),17))+
        ggplot2::annotate("point",x=highlights$BPcum,y=-log10(highlights$pval),col=highlights$region_col,size=0.6)+
        ggplot2::scale_x_continuous( labels = axisdf$chromosome, breaks= axisdf$center, expand = ggplot2::expand_scale(mult = c(0.02, 0.02))) +
        ggplot2::scale_y_continuous(expand = c(0, 0), limits=c(1,ytop), breaks=seq(from=2, to=ytop,by=2) )+
        ggplot2::theme_light() +
        ggplot2::theme(
          legend.position="none",
          panel.grid.major.x = ggplot2::element_blank(),
          panel.grid.minor.x = ggplot2::element_blank()
        )+
        ggplot2::xlab("Chromosome")+ggplot2::ylab(expression("-log"[10] * "(p)"))+
        ggplot2::geom_hline(yintercept = -log10(0.05/(multcomp)), col="red")+
        ggplot2::geom_hline(yintercept=tmpcutoff,col="blue")+
        ggplot2::ggtitle(label)

      # ggsave(paste("Plots/Manhattans_regionhighlight/single_env/",traits[i],"_",envs[q],".png",sep=""),plot, height=4.5,width=7.5, units="in",dpi=300)

      #png(paste("Plots/Manhattans_regionhighlight/single_env/",traits[i],"_",envs[q],".png",sep=""),height=4.5,width=7.5, units = "in",res = 300)

      # pdf(paste("Plots/Colocalization/Manhattans_regionhighlight/single_env/",traits[i],"_",envs[q],".pdf",sep=""),height=4.5,width=7.5)
      pdf(get_project_dir(subdir = "Plots/Manhattans_regionhighlight/",file = paste(traits[i],".pdf",sep = "")),height=4.5,width=7.5)
      print(plot)
      dev.off()

      # assign(envs[q],plot)
    }
    # if(length(envs) > 1){
    #   #this should be fixed if there are more than 3 environments
    #   comb.plot.list<-mget(paste(envs[1:length(envs)]))
    #
    #   comb.plot<-plot_grid(plotlist = comb.plot.list,align="h",nrow=2)
    #
    #   #ggsave(paste("Plots/Manhattans_regionhighlight/Manhattan-region-",traits[i],".png",sep=""),plot=comb.plot,height=9,width=15, units="in",dpi=300)
    #   pdf(paste("Plots/Colocalization/Manhattans_regionhighlight/Manhattan-region-",traits[i],".png",sep=""),height=4.5,width=7.5)
    #   print(comb.plot)
    #   dev.off()
    #
    # }
  }
}
