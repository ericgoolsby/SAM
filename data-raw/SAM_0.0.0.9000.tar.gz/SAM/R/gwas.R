#' @export
get_SAM_meta_dir <- function()
{
  path <- tools::R_user_dir("SAM",which = "data")
  if(!dir.exists(path))
  {
    dir.create(path,recursive = TRUE)
  }
  if(!(substr(path, nchar(path), nchar(path)) %in% c("/","\\"))) path <- paste(path,"/",sep = "")
  path
}

#' @export
set_SAM_dir <- function(dir = "~/SAM/",RStudio_project = FALSE)
{
  path <- get_SAM_meta_dir()
  if(RStudio_project) dir <- getwd()
  dir <- path.expand(dir)
  write.csv(x = data.frame(SAM_dir = dir,RStudio_project = RStudio_project),file = paste(path,"/SAM_dir.csv",sep = ""))
}

#' @export
get_SAM_dir <- function(subdir,file)
{
  path <- get_SAM_meta_dir()
  if(!file.exists(paste(path,"/SAM_dir.csv",sep = "")))
  {
    dir <- path.expand("~/SAM")
    flag <- 1

    while(flag)
    {
      if(!dir.exists(dir) || ("SAM.bed" %in% list.files(path = paste(dir,"/Tools",sep = ""))))
      {
        if(!dir.exists(dir))
        {
          cat(rlang::format_error_bullets(c(
            `!` = "No folder for SAM tools and output has been created (required for first time use of the package).")))
          Sys.sleep(1)
          cat("\n")
          cat(rlang::format_error_bullets(c(
            `>` = "Attempting to create a folder in the following default location:",` ` = paste("\t",path.expand(dir),sep = ""))))
          Sys.sleep(1)
        }
        set_SAM_dir(dir = dir)
        get_SAM_dir()
        cat("\n")
        cat(rlang::format_error_bullets(c(
          `v` = "Folder successfully created!")))
        cat("\n\n")
        Sys.sleep(1)
        cat(rlang::format_error_bullets(c(`i` = paste("NOTE: If preferred, you can instead set a custom path by running e.g.:\n\n\t",
                                                    "set_SAM_dir(dir = 'C:/your/custom/path/')",sep = ""))))
        cat("\n\n")
        cat(rlang::format_error_bullets(c(`*` = paste("(just be sure to move all files from ",
                                                    path.expand("~/SAM/")," to your new directory prior to running additional functions).\n\n",sep = ""))))
        cat("\n")
        flag <- 0
      } else
      {
        dir <- gsub(pattern = paste("_",flag,sep = ""),replacement = "",x = dir)
        flag <- flag + 1
        dir <- paste(dir,"_",flag,sep = "")
      }
    }
  }
  dir <- path.expand(read.csv(file = paste(path,"/SAM_dir.csv",sep = ""))$SAM_dir[1])
  if(!(substr(dir, nchar(dir), nchar(dir)) %in% c("/","\\"))) dir <- paste(dir,"/",sep = "")

  if(!missing(subdir))
  {
    dir <- paste(dir,subdir,sep = "")
  }
  if(!(substr(dir, nchar(dir), nchar(dir)) %in% c("/","\\"))) dir <- paste(dir,"/",sep = "")
  if(!dir.exists(dir)) dir.create(dir,recursive = TRUE)
  if(!missing(file))
  {
    dir <- paste(dir,file,sep = "")
  }
  dir
}

#' @export
set_project <- function(name = "Project_Name",RStudio_project = FALSE)
{
  if(RStudio_project) name <- getwd()
  if(!(substr(name, nchar(name), nchar(name)) %in% c("/","\\"))) name <- paste(name,"/",sep = "")
  path <- get_SAM_meta_dir()
  get_SAM_dir()
  write.csv(x = data.frame(Project_Name = name,RStudio_project = RStudio_project),file = paste(path,"project_dir.csv",sep = ""))
}

#' @export
get_project_dir <- function(subdir,file)
{
  path <- get_SAM_meta_dir()
  if(!file.exists(paste(path,"project_dir.csv",sep = "")))
  {
    SAMdir <- get_SAM_dir()
    if(!file.exists(paste(path,"/project_dir.csv",sep = "")))
    {
      dir <- "Unnamed_Project" # paste(SAMdir,"Unnamed_Project",sep = "")
      flag <- 1

      while(flag)
      {
        if(!dir.exists(paste(SAMdir,dir,sep = "")))
        {
          set_project(name = dir)
          Sys.sleep(1)
          cat(rlang::format_error_bullets(c(
            `!` = "No project folder has been created.")))
          Sys.sleep(1)
          cat("\n")
          cat(rlang::format_error_bullets(c(
            `>` = "Attempting to create a folder in the following default location:",` ` = paste("\t",path.expand(dir),sep = ""))))
          Sys.sleep(1)
          get_project_dir()
          cat("\n")
          cat(rlang::format_error_bullets(c(
            `v` = "Folder successfully created!")))
          cat("\n\n")
          Sys.sleep(1)
          # cat(rlang::format_error_bullets(c(`i` = paste("NOTE: If preferred, you can instead set a custom path by running e.g.:\n\n\t",
          #                                               "set_project_dir(dir = 'C:/your/custom/path/')",sep = ""))))
          # cat("\n\n")
          # cat(rlang::format_error_bullets(c(`*` = paste("(just be sure to move all files from ",
          #                                               path.expand("~/SAM/")," to your new directory prior to running additional functions).",sep = ""))))
          flag <- 0
        } else
        {
          dir <- gsub(pattern = paste("_",flag,sep = ""),replacement = "",x = dir)
          flag <- flag + 1
          dir <- paste(dir,"_",flag,sep = "")
        }
      }
    }
  }
  project_dir <- read.csv(file = paste(path,"project_dir.csv",sep = ""),row.names = 1)
  if(project_dir$RStudio_project[1])
  {
    dir <- project_dir$Project_Name[1]
  } else
  {
    dir <- paste(get_SAM_dir(),read.csv(file = paste(path,"project_dir.csv",sep = ""),row.names = 1)$Project_Name[1],sep = "")
  }
  if(!missing(subdir))
  {
    dir <- paste(dir,subdir,sep = "")
  }
  if(!(substr(dir, nchar(dir), nchar(dir)) %in% c("/","\\"))) dir <- paste(dir,"/",sep = "")
  if(!dir.exists(dir)) dir.create(dir,recursive = TRUE)
  if(!missing(file))
  {
    dir <- paste(dir,file,sep = "")
  }
  dir
}

#' @export
get_snp_data <- function()
{
  path <- get_SAM_dir()
  if(!file.exists(get_SAM_dir(subdir = "Tools",file = "SAM.bed")))
  {
    if(!file.exists(get_SAM_dir(subdir = "Tools",file = "SAM.bed.zip")))
    {
      download.file("https://github.com/ericgoolsby/SAM/raw/main/data-raw/SAM.bed.zip",destfile = get_SAM_dir(subdir = "Tools",file = "SAM.bed.zip"))
    }
    zip::unzip(zipfile = get_SAM_dir(subdir = "Tools",file = "SAM.bed.zip"),exdir = get_SAM_dir(subdir = "Tools"))
  }
  BEDMatrix::BEDMatrix(get_SAM_dir(subdir = "Tools",file = "SAM.bed"),n = 261,p = 1469397)
}

#' @export
get_bim_data <- function()
{
  if(!file.exists(get_SAM_dir(subdir = "Tools",file = "SAM.bim")))
  {
    if(!file.exists(get_SAM_dir(subdir = "Tools",file = "SAM.bim.zip")))
    {
      download.file("https://github.com/ericgoolsby/SAM/raw/main/data-raw/SAM.bim.zip",destfile = get_SAM_dir(subdir = "Tools",file = "SAM.bim.zip"))
    }
    zip::unzip(zipfile = get_SAM_dir(subdir = "Tools",file = "SAM.bim.zip"),exdir = get_SAM_dir(subdir = "Tools"))
  }
  get_SAM_dir(subdir = "Tools",file = "SAM")
}

#' @export
get_gff3 <- function()
{
  if(!file.exists(get_SAM_dir(subdir = "Tools",file = "SAM_gff3.txt")))
  {
    if(!file.exists(get_SAM_dir(subdir = "Tools",file = "SAM_gff3.zip")))
    {
      download.file("https://github.com/ericgoolsby/SAM/raw/main/data-raw/SAM_gff3.zip",destfile = get_SAM_dir(subdir = "Tools",file = "SAM_gff3.zip"))
    }
    zip::unzip(zipfile = get_SAM_dir(subdir = "Tools",file = "SAM_gff3.zip"),exdir = get_SAM_dir(subdir = "Tools"))
  }
  get_SAM_dir(subdir = "Tools",file = "SAM_gff3.txt")
}

#' @export
get_blocks <- function()
{
  if(!file.exists(get_SAM_dir(subdir = "Tools",file = "SAM.blocks.det")))
  {
    if(!file.exists(get_SAM_dir(subdir = "Tools",file = "SAM_blocks.zip")))
    {
      download.file("https://github.com/ericgoolsby/SAM/raw/main/data-raw/SAM_blocks.zip",destfile = get_SAM_dir(subdir = "Tools",file = "SAM_blocks.zip"))
    }
    zip::unzip(zipfile = get_SAM_dir(subdir = "Tools",file = "SAM_blocks.zip"),exdir = get_SAM_dir(subdir = "Tools"))
  }
  c(get_SAM_dir(subdir = "Tools",file = "SAM.blocks.det"),
    get_SAM_dir(subdir = "Tools",file = "SAM.map"))
}


#' @export
get_plink <- function()
{
  if(!file.exists(get_SAM_dir(subdir = "Tools",file = "plink.exe")))
  {
    if(!file.exists(get_SAM_dir(subdir = "Tools",file = "plink.zip")))
    {
      download.file("https://github.com/ericgoolsby/SAM/raw/main/data-raw/plink.zip",destfile = get_SAM_dir(subdir = "Tools",file = "plink.zip"))
    }
    zip::unzip(zipfile = get_SAM_dir(subdir = "Tools",file = "plink.zip"),exdir = get_SAM_dir(subdir = "Tools"))
  }
  get_SAM_dir(subdir = "Tools",file = "plink.exe")
}

#' @export
gwas <- function(data,trait,save = TRUE,overwrite = FALSE,grid_evals = 5,pval_optim = .01,use_pca = TRUE,PCs = 1:4,use_kinship = TRUE,snp_numbers,absolute = TRUE,REML = TRUE,verbose = 0)
{
  if(REML) REML <- 1L else REML <- 0L

  if(!missing(snp_numbers))
  {
    nsnps <- length(snp_numbers)
    if(length(snp_numbers) == nrow(snpInfo))
    {
      absolute <- TRUE
    } else if(length(snp_numbers) == (nrow(snpInfo) - nrow(snpDuplicates)))
    {
      if(all(snp_numbers == 1:(nrow(snpInfo) - nrow(snpDuplicates))))
      {
        absolute <- FALSE
      } else
      {
        stop("Invalid snp_numbers.")
      }
    } else
    {
      if(!absolute) stop("absolute must be set to TRUE if only running a subset of snp_numbers")
    }
  } else
  {
    snp_numbers <- 1:(if(!absolute) nrow(snpInfo)-nrow(snpDuplicates) else nrow(snpInfo))
    nsnps <- length(snp_numbers)
  }

  snps <- get_snp_data()

  if(!absolute)
  {
    snps <- snps[,-snpDuplicates[,1]]
  }

  rownames(snps) <- lines

  # data <- myco
  # traits <- "maxCol"
  # tr <- i <- 1
  # grid_evals <- 5
  # use_pca <- use_kinship <- TRUE
  # PCs <- 1:4
  # tr <- 1
  # trait <- traits[tr]
  data <- data[data$SAM %in% lines,]
  if(any(is.na(data[,trait])))
  {
    is_na <- which(is.na(data[,trait]))
    data <- data[-is_na,,drop = FALSE]
  }
  Y <- data[,trait]
  X <- cbind(intercept = rep(1,length(Y)),SNP = 0)
  if(use_pca)
  {
    if(length(PCs) > 0)
    {
      pca <- pca[data$SAM,PCs,drop = FALSE]
      X <- cbind(X,pca)
    }
  }

  if(use_kinship) kinship <- kinship[data$SAM,data$SAM]

  snps <- snps[data$SAM,,drop = FALSE]

  if(grid_evals==5)
  {
    hs <- seq(.1,.8,length = grid_evals)
  } else
  {
    hs <- seq(0,.95,length = grid_evals)
  }

  Vinvs <- lapply(hs,function(h){
    k2 <- kinship
    Vh <- (k2) * h
    diag(Vh) <- diag((Vh)) + (1-h) # ((diag(k2)-diag(Vh)) * (1-h))

    cholV <- Rfast::cholesky(Vh,parallel = nrow(Vh) > 1000)
    logd <- 2*sum(log(diag(cholV)))
    list(cholV=cholV,logd=logd)
  })
  p <- ncol(X)
  n <- length(Y)
  cvs <- lapply(Vinvs,function(X) t(X$cholV))
  logds <- sapply(Vinvs,function(X) X$logd)
  ll <- numeric(length(hs))
  sig2 <- numeric(length(hs))
  beta <- numeric(p)
  Bhat <- numeric(p)
  XXhat <- matrix(0,p,p)
  cholV <- matrix(0,n,n)
  bX <- matrix(0,n,p)
  bY <- numeric(n)
  XX <- matrix(0,p,p)
  XY <- matrix(0,p,1)
  bX <- matrix(0,n,p)
  V <- matrix(0,n,n)
  cholV <- matrix(0,n,n)
  logd <- 0
  # REML <- 1
  XXinv <- matrix(0,p,p)

  hvals <- logliks <- pvals <- betas <- sig2s <- SEs <- numeric(nsnps)

  for(i in 1:nsnps)
  {
    if(verbose > 0) if((i %% 10^(5:0)[verbose]) == 0) cat("SNP ",i," (of ",nsnps,")\n",sep = "")
    X[,"SNP"] <- snps[,snp_numbers[i]]

    lmm_fit_multi(X = X,Y = Y,cholVs = cvs,logds = logds,n = n,p = p,REML = 1,cholV = cholV,Xstar = bX,Ystar = bY,XX = XX,XY = XY,B = beta,logLiks = ll,sig2 = sig2,Bhat = Bhat,XXhat = XXhat)

    llmax_ind <- which.max(ll)
    logliks[i] <- max(ll)
    sig2s[i] <- sig2[llmax_ind]
    betas[i] <- Bhat[2]
    SEs[i] <- sqrt(solve(XXhat/sig2s[i])[2,2])
    pvals[i] <- pchisq((betas[i] / SEs[i])^2,df = 1,lower.tail = FALSE)
    hvals[i] <- hs[llmax_ind]

    if(pvals[i] < pval_optim)
    {

      o <- optim(par = hvals[i],fn = function(h)
        lmm_gradient_logl(X = X,Y = Y,K = kinship,logd = logd,n = n,p = p,REML = REML,h = h,Xstar = bX,Ystar = bY,XX = XX,XY = XY,B = beta,V = V,cholV = cholV,XXinv = XXinv,ret_logl = 1L),
        control = list(fnscale = -1),
        method = "L-BFGS-B",
        lower = 0,
        upper = .99)

      logliks[i] <- o$val
      hvals[i] <- o$par
      sig2s[i] <- lmm_gradient_logl(X = X,Y = Y,K = kinship,logd = logd,n = n,p = p,REML = REML,h = hvals[i],Xstar = bX,Ystar = bY,XX = XX,XY = XY,B = beta,V = V,cholV = cholV,XXinv = XXinv,ret_logl = 2L)
      betas[i] <- beta[2]
      SEs[i] <- sqrt(XXinv[2,2])
      pvals[i] <- pchisq((betas[i] / SEs[i])^2,df = 1,lower.tail = FALSE)
    }
  }

  results <- data.frame(logl=logliks,sig2=sig2s,beta=betas,SE=SEs,pval=pvals,h=hvals)
  tmp_snpInfo <- snpInfo
  if(!absolute)
  {
    tmp_snpInfo <- tmp_snpInfo[-snpDuplicates[,1],]
  }

  tmp_snpInfo <- tmp_snpInfo[snp_numbers[snp_numbers %in% 1:nrow(snpInfo)],]
  results$chromosome <- tmp_snpInfo$chr
  results$position <- tmp_snpInfo$position
  results$snp.id <- paste("Ha412HOChr",ifelse(tmp_snpInfo$chr < 10,"0",""),tmp_snpInfo$chr,":",tmp_snpInfo$position,sep = "")
  rm(tmp_snpInfo)
  if(!absolute)
  {
    results <- results[snpInfo$original,]
    results$snp.id <- paste("Ha412HOChr",ifelse(snpInfo$chr < 10,"0",""),snpInfo$chr,":",snpInfo$position,sep = "")
    results$position <- snpInfo$position
    results$chromosome <- snpInfo$chr
    rownames(results) <- 1:nrow(results)
  }

  results <- list(GWAS = results,pheno = Y)

  if(save)
  {
    if(nrow(results$GWAS) != nrow(snpInfo))
    {
      filename <- get_project_dir(subdir = "GWAS/subset/",file = paste(trait,".RData",sep = ""))
    } else
    {
      filename <- get_project_dir(subdir = "GWAS/",file = paste(trait,".RData",sep = ""))
    }

    version <- 1
    if(!overwrite && file.exists(paste(filename)))
    {
      while(file.exists(filename))
      {
        trait <- gsub(pattern = paste("_",version,sep = ""),replacement = "",x = trait)
        version <- version + 1
        trait <- paste(trait,"_",version,sep = "")
        filename <- get_project_dir(subdir = "GWAS/subset",file = paste(trait,".RData",sep = ""))
      }
      warning("File already exists and overwrite = FALSE. Saving results to ",filename," instead.\n",
              "\n*** NOTE: If you want this version of the results to be used by other functions in the pipeline,\n",
              "*** delete the old file and rename this file to ",gsub(pattern = paste("_",version,sep = ""),replacement = "",x = trait),".RData.\n\n",
              "*** Alternatively, you can use the name ",trait,".RData in function calls, OR simply rerun this function but set overwrite = TRUE.")
    }
    filename <- get_project_dir(subdir = "GWAS/",file = paste(trait,".RData",sep = ""))
    save_success <- try({
      save(results,file = filename)
      cat("\nResults saved to ",filename,sep = "")
    },silent = TRUE)
    if(inherits(save_success,"try-error")) cat("\nResults FAILED to save to ",filename,sep = "")
  }
  results
}

#' @export
get_gwas <- function(trait)
{
  filename <- get_project_dir(subdir = "GWAS/",file = paste(trait,".RData",sep = ""))
  if(file.exists(filename))
  {
    load(file = filename)
  } else
  {
    stop("Saved file does not exist. Must provide results data frame.")
  }
  results
}

#' @export
manhattan <- function(trait,results)
{
  if(missing(results))
  {
    results <- get_gwas(trait)$GWAS
  }

  ytop <- -log10(min(results$pval,na.rm=TRUE))
  if (ytop > 10){ ytop = ytop+2} else { ytop = 10}

  multcomp <- 19918
  suggthresh <- 0.001 ## draw line at "suggestive" SNPs (threshold fraction of snips are above the blue line)

  tmpcutoff <- quantile(results$pval, as.numeric(as.character(suggthresh)))[[1]]
  filename <- get_project_dir(subdir = "Plots/Manhattans/",file = paste(trait,"_ManhattanPlot.pdf",sep = ""))
  pdf(
    filename,
    height = 5.5,
    width = 7.5
  )

  if (length(which(results$pval < .1)) < 1) {
    plot(10:1)  ## draw empty plot if no snips are above minimum plotting threshold, plot fails otherwise
  } else {
    qqman::manhattan(
      results[results$pval <= .1,],
      suggestiveline = -log10(tmpcutoff),
      genomewideline = -log10(0.05 / (multcomp)),
      chr = "chromosome",bp = "position",p = "pval",snp = "snp.id",
      col = RColorBrewer::brewer.pal(8,"Dark2")[c(1,8)],
      cex = 0.5,cex.axis=0.8,ylim=c(.99999,ytop),
      mtext(trait, side = 3, line = 0))
  }
  dev.off()
  cat("\nWritten to: ",
      filename,"\n")
}
