## usethis namespace: start
#' @useDynLib SAM, .registration = TRUE
#' @importFrom Rcpp sourceCpp
#' @import RcppEigen
## usethis namespace: end
NULL
