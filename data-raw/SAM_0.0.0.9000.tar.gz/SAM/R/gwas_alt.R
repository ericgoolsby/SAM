gwas_alt <- function(data,trait,grid_evals = 5,pval_optim = .01,use_pca = TRUE,PCs = 1:4,use_kinship = TRUE,snp_numbers,absolute = FALSE,REML = TRUE,verbose = 0)
{
  save <- overwrite <- FALSE
  if(REML) REML <- 1L else REML <- 0L

  if(!missing(snp_numbers))
  {
    nsnps <- length(snp_numbers)
    if(length(snp_numbers) == nrow(snpInfo))
    {
      absolute <- TRUE
    } else if(length(snp_numbers) == (nrow(snpInfo) - nrow(snpDuplicates)))
    {
      if(all(snp_numbers == 1:(nrow(snpInfo) - nrow(snpDuplicates))))
      {
        absolute <- FALSE
      } else
      {
        stop("Invalid snp_numbers.")
      }
    } else
    {
      if(!absolute) stop("absolute must be set to TRUE if only running a subset of snp_numbers")
    }
  } else
  {
    snp_numbers <- 1:(if(!absolute) nrow(snpInfo)-nrow(snpDuplicates) else nrow(snpInfo))
    nsnps <- length(snp_numbers)
  }

  snps <- get_snp_data()

  if(!absolute)
  {
    snps <- snps[,-snpDuplicates[,1]]
  }

  rownames(snps) <- lines

  # data <- myco
  # traits <- "maxCol"
  # tr <- i <- 1
  # grid_evals <- 5
  # use_pca <- use_kinship <- TRUE
  # PCs <- 1:4
  # tr <- 1
  # trait <- traits[tr]
  data <- data[data$SAM %in% lines,]
  if(any(is.na(data[,trait])))
  {
    is_na <- which(is.na(data[,trait]))
    data <- data[-is_na,,drop = FALSE]
  }
  Y <- data[,trait]
  X <- cbind(intercept = rep(1,length(Y)),SNP = 0)
  if(use_pca)
  {
    if(length(PCs) > 0)
    {
      pca <- pca[data$SAM,PCs,drop = FALSE]
      X <- cbind(X,pca)
    }
  }

  if(use_kinship) kinship <- kinship[data$SAM,data$SAM]

  snps <- snps[data$SAM,,drop = FALSE]

  if(grid_evals==5)
  {
    hs <- seq(.1,.8,length = grid_evals)
  } else
  {
    hs <- seq(0,.95,length = grid_evals)
  }

  Vinvs <- lapply(hs,function(h){
    k2 <- kinship
    Vh <- (k2) * h
    diag(Vh) <- diag((Vh)) + (1-h) # ((diag(k2)-diag(Vh)) * (1-h))

    cholV <- Rfast::cholesky(Vh,parallel = nrow(Vh) > 1000)
    logd <- 2*sum(log(diag(cholV)))
    list(cholV=cholV,logd=logd)
  })
  p <- ncol(X)
  n <- length(Y)
  cvs <- lapply(Vinvs,function(X) t(X$cholV))
  logds <- sapply(Vinvs,function(X) X$logd)
  ll <- numeric(length(hs))
  sig2 <- numeric(length(hs))
  beta <- numeric(p)
  Bhat <- numeric(p)
  XXhat <- matrix(0,p,p)
  cholV <- matrix(0,n,n)
  bX <- matrix(0,n,p)
  bY <- numeric(n)
  XX <- matrix(0,p,p)
  XY <- matrix(0,p,1)
  bX <- matrix(0,n,p)
  V <- matrix(0,n,n)
  cholV <- matrix(0,n,n)
  logd <- 0
  # REML <- 1
  XXinv <- matrix(0,p,p)

  hvals <- logliks <- pvals <- betas <- sig2s <- SEs <- numeric(nsnps)

  extra_results <- data.frame(pval = pvals,
                              AIC_1=NA,RSS_ML_1=NA,pval_ML_1=NA,RSS_REML_1=NA,pval_REML_1=NA,
                              AIC_2=NA,RSS_ML_2=NA,pval_ML_2=NA,RSS_REML_2=NA,pval_REML_2=NA,
                              AIC_3=NA,RSS_ML_3=NA,pval_ML_3=NA,RSS_REML_3=NA,pval_REML_3=NA,
                              AIC_4=NA,RSS_ML_4=NA,pval_ML_4=NA,RSS_REML_4=NA,pval_REML_4=NA,
                              AIC_5=NA,RSS_ML_5=NA,pval_ML_5=NA,RSS_REML_5=NA,pval_REML_5=NA,
                              AIC_6=NA,RSS_ML_6=NA,pval_ML_6=NA,RSS_REML_6=NA,pval_REML_6=NA)
  loo_mat_ML <- loo_mat_REML <- array(NA,dim = c(n,p,nsnps))

  if(verbose > 0) cat("\n")
  for(i in 1:nsnps)
  {
    if(verbose > 0) if((i %% 10^(5:0)[verbose]) == 0) cat("SNP ",i," (of ",nsnps,")\n",sep = "")
    X[,"SNP"] <- snps[,snp_numbers[i]]

    lmm_fit_multi(X = X,Y = Y,cholVs = cvs,logds = logds,n = n,p = p,REML = 1,cholV = cholV,Xstar = bX,Ystar = bY,XX = XX,XY = XY,B = beta,logLiks = ll,sig2 = sig2,Bhat = Bhat,XXhat = XXhat)

    llmax_ind <- which.max(ll)
    logliks[i] <- max(ll)
    sig2s[i] <- sig2[llmax_ind]
    betas[i] <- Bhat[2]
    SEs[i] <- sqrt(solve(XXhat/sig2s[i])[2,2])
    pvals[i] <- pchisq((betas[i] / SEs[i])^2,df = 1,lower.tail = FALSE)
    hvals[i] <- hs[llmax_ind]

    if(pvals[i] < pval_optim)
    {
      print(i)

      o <- optim(par = hvals[i],fn = function(h)
        lmm_gradient_logl(X = X,Y = Y,K = kinship,logd = logd,n = n,p = p,REML = REML,h = h,Xstar = bX,Ystar = bY,XX = XX,XY = XY,B = beta,V = V,cholV = cholV,XXinv = XXinv,ret_logl = 1L),
        control = list(fnscale = -1),
        method = "L-BFGS-B",
        lower = 0,
        upper = .99)

      logliks[i] <- o$val
      hvals[i] <- o$par
      sig2s[i] <- lmm_gradient_logl(X = X,Y = Y,K = kinship,logd = logd,n = n,p = p,REML = REML,h = hvals[i],Xstar = bX,Ystar = bY,XX = XX,XY = XY,B = beta,V = V,cholV = cholV,XXinv = XXinv,ret_logl = 2L)
      betas[i] <- beta[2]
      SEs[i] <- sqrt(XXinv[2,2])
      pvals[i] <- pchisq((betas[i] / SEs[i])^2,df = 1,lower.tail = FALSE)

      for(REML_temp in 0:1) for(j in 1:6)
      {
        X_temp <- X[,1:j,drop = FALSE]
        p_temp <- j
        bX_temp <- bX[,1:j,drop = FALSE]
        XX_temp <- XX[1:j,1:j,drop = FALSE]
        XY_temp <- XY[1:j,,drop = FALSE]
        beta_temp <- beta[1:j]
        XXinv_temp <- XXinv[1:j,1:j,drop = FALSE]
        # REML_temp <- 0L
        o <- optim(par = hvals[i],fn = function(h)
          lmm_gradient_logl(X = X_temp,Y = Y,K = kinship,logd = logd,n = n,p = p_temp,REML = REML_temp,h = h,Xstar = bX_temp,Ystar = bY,XX = XX_temp,XY = XY_temp,B = beta_temp,V = V,cholV = cholV,XXinv = XXinv_temp,ret_logl = 1L),
          control = list(fnscale = -1),
          method = "L-BFGS-B",
          lower = 0,
          upper = .99)

        hval_temp <- o$par
        sig2_temp <- lmm_gradient_logl(X = X_temp,Y = Y,K = kinship,logd = logd,n = n,p = p_temp,REML = REML_temp,h = hval_temp,Xstar = bX_temp,Ystar = bY,XX = XX_temp,XY = XY_temp,B = beta_temp,V = V,cholV = cholV,XXinv = XXinv_temp,ret_logl = 2L)
        if(j>1)
        {
          betas_temp <- beta_temp
          SEs_temp <- sqrt(XXinv_temp[2,2])
          pvals_temp <- pchisq((betas_temp[2] / SEs_temp)^2,df = 1,lower.tail = FALSE)
        } else
        {
          pvals_temp <- 1
        }

        cholVinv <- forwardsolve(cholV*sqrt(sig2_temp),diag(nrow(cholV)))
        bX_temp <- cholVinv %*% X_temp
        bY <- cholVinv %*% Y
        H <- bX_temp %*% solve(crossprod(bX_temp)) %*% t(bX_temp)
        res <- bY-bX_temp%*%beta_temp
        df <- ncol(X_temp) + 2
        AIC_temp <- 1*df - 2*o$value
        rss_temp <- crossprod(res/(1-diag(H)))/length(Y)
        if(REML_temp==1L) {
          extra_results[i,paste("RSS_REML_",j,sep = "")] <- rss_temp
          extra_results[i,paste("pval_REML_",j,sep = "")] <- pvals_temp
        } else
        {
          extra_results[i,paste("AIC_",j,sep = "")] <- AIC_temp
          extra_results[i,paste("RSS_ML_",j,sep = "")] <- rss_temp
          extra_results[i,paste("pval_ML_",j,sep = "")] <- pvals_temp

        }

        ### BEGIN ##############################################################
        for(k in 1:nrow(X))
        {
          X_temp <- X[-k,1:j,drop = FALSE]
          p_temp <- j
          bX_temp <- bX[-k,1:j,drop = FALSE]
          XX_temp <- XX[1:j,1:j,drop = FALSE]
          XY_temp <- XY[1:j,,drop = FALSE]
          beta_temp <- beta[1:j]
          XXinv_temp <- XXinv[1:j,1:j,drop = FALSE]
          V_temp <- V[-k,-k]
          cholV_temp <- cholV[-k,-k]
          kinship_temp <- kinship[-k,-k]
          # REML_temp <- 0L
          o <- optim(par = hvals[i],fn = function(h)
            lmm_gradient_logl(X = X_temp,Y = Y,K = kinship_temp,logd = logd,n = n,p = p_temp,REML = REML_temp,h = h,Xstar = bX_temp,Ystar = bY,XX = XX_temp,XY = XY_temp,B = beta_temp,V = V_temp,cholV = cholV_temp,XXinv = XXinv_temp,ret_logl = 1L),
            control = list(fnscale = -1),
            method = "L-BFGS-B",
            lower = 0,
            upper = .99)

          hval_temp <- o$par
          sig2_temp <- lmm_gradient_logl(X = X_temp,Y = Y,K = kinship,logd = logd,n = n,p = p_temp,REML = REML_temp,h = hval_temp,Xstar = bX_temp,Ystar = bY,XX = XX_temp,XY = XY_temp,B = beta_temp,V = V,cholV = cholV,XXinv = XXinv_temp,ret_logl = 2L)
          if(REML_temp == 1L)
          {
            loo_mat_ML[k,j,i] <- (X[k,1:j,drop = FALSE] %*% beta_temp)[1]
          } else
          {
            loo_mat_REML[k,j,i] <- (X[k,1:j,drop = FALSE] %*% beta_temp)[1]
          }
        }
        ### END ################################################################


      }


    }
    # c(logl=logliks[i],sig2=sig2s[i],beta=betas[i],SE=SEs[i],pval=pvals[i],h=hvals[i])
  }

  results <- data.frame(logl=logliks,sig2=sig2s,beta=betas,SE=SEs,pval=pvals,h=hvals)
  extra_results$pval <- pvals
  tmp_snpInfo <- snpInfo
  if(!absolute)
  {
    tmp_snpInfo <- tmp_snpInfo[-snpDuplicates[,1],]
  }

  tmp_snpInfo <- tmp_snpInfo[snp_numbers[snp_numbers %in% 1:nrow(snpInfo)],]
  results$chromosome <- tmp_snpInfo$chr
  results$position <- tmp_snpInfo$position
  results$snp.id <- paste("Ha412HOChr",ifelse(tmp_snpInfo$chr < 10,"0",""),tmp_snpInfo$chr,":",tmp_snpInfo$position,sep = "")
  rm(tmp_snpInfo)
  if(!absolute)
  {
    results <- results[snpInfo$original,]
    rownames(results) <- 1:nrow(results)
    extra_results <- extra_results[snpInfo$original,]
    rownames(extra_results) <- 1:nrow(extra_results)
    loo_mat_ML <- loo_mat_ML[,,snpInfo$original]
    loo_mat_ML <- loo_mat_REML[,,snpInfo$original]

  }

  results <- list(GWAS = results,pheno = Y)

  if(save)
  {
    if(nrow(results$GWAS) != nrow(snpInfo))
    {
      filename <- get_project_dir(subdir = "GWAS/subset/",file = paste(trait,".RData",sep = ""))
    } else
    {
      filename <- get_project_dir(subdir = "GWAS/",file = paste(trait,".RData",sep = ""))
    }

    version <- 1
    if(!overwrite && file.exists(paste(filename)))
    {
      while(file.exists(filename))
      {
        trait <- gsub(pattern = paste("_",version,sep = ""),replacement = "",x = trait)
        version <- version + 1
        trait <- paste(trait,"_",version,sep = "")
        filename <- get_project_dir(subdir = "GWAS/subset",file = paste(trait,".RData",sep = ""))
      }
      warning("File already exists and overwrite = FALSE. Saving results to ",filename," instead.\n",
              "\n*** NOTE: If you want this version of the results to be used by other functions in the pipeline,\n",
              "*** delete the old file and rename this file to ",gsub(pattern = paste("_",version,sep = ""),replacement = "",x = trait),".RData.\n\n",
              "*** Alternatively, you can use the name ",trait,".RData in function calls, OR simply rerun this function but set overwrite = TRUE.")
    }
    filename <- get_project_dir(subdir = "GWAS/",file = paste(trait,".RData",sep = ""))
    save_success <- try({
      save(results,file = filename)
      cat("\nResults saved to ",filename,sep = "")
    },silent = TRUE)
    if(inherits(save_success,"try-error")) cat("\nResults FAILED to save to ",filename,sep = "")
  }
  results$extra_results <- extra_results
  results$loo_mat_ML <- loo_mat_ML
  results$loo_mat_REML <- loo_mat_REML
  results
}
