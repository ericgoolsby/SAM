#' @export
blocks_heatmaps <- function(traits)
{
  # files <- list.files(get_project_dir("GWAS"))
  # traits <- gsub("C:/Users/ericg/Documents/SAM/Height/GWAS/","",gsub(".RData","",files))
  multcomp <- 19918
  thresh <- 0.05/(multcomp)
  suggthresh <- 0.001

  sig.blocks <- NULL #empty object to merge against
  sug.blocks <- NULL
  sig.snips.save <- NULL
  sug.snips.save <- NULL

  envs <- FALSE
  for (i in 1:length(traits)){

    for(q in 1:length(envs)) {

      # print(paste(traits[i],envs[q]))
      results <- get_gwas(traits[i])
      data <- results$pheno
      results <- results$GWAS
      snpInfo$SNP <- paste("Ha412HOChr",ifelse(snpInfo$chr < 10,"0",""),snpInfo$chr,":",snpInfo$position,sep = "")
      trait <- traits[i]
      trait.range <- abs(diff(range(data,na.rm=TRUE)))
      sig.bins<-NULL
      sug.bins<-NULL

      if(nrow(results) < nrow(snpInfo))
      {
        new_results <- data.frame(as.data.frame(matrix(1,nrow = nrow(snpInfo),ncol = ncol(results)-1)),snp.id=snpInfo$SNP)
        colnames(new_results) <- colnames(results)
        new_results[match(results$snp.id,new_results$snp.id),] <- results
        results <- new_results
        rm(new_results)
      }

      tempcutoff <- quantile(results$pval, as.numeric(as.character(suggthresh)),na.rm=TRUE)[[1]]
      sug.snips <- results[which(results$pval<tempcutoff & results$pval>thresh), ]

      if (min(results$pval,na.rm=T)<thresh){
        sig.snips <- results[which(results$pval<thresh), ]
        sig.snips.list <- sig.snips
        sig.snips.list$trait <- traits[i]
        if(envs) sig.snips.list$env <- envs[q]

        sig.snips.save <- rbind(sig.snips.save,sig.snips.list) ### save list of significant snps


        sig.bins <- merge(sig.snips,snpInfo,by.x="snp.id",by.y="SNP")
        sig.bins$RES <- abs(2*sig.bins$beta)/trait.range
        sig.bins <- sig.bins |> dplyr::group_by(hapID) |> dplyr::summarise(NSNP=length(pval),beta=max(beta),min_p=min(pval), RES=max(RES))
        sig.bins$trait<-traits[i]
        if(envs) sig.bins$env<-envs[q]
        sig.bins$pvalue <- "significant"
        print(paste(dim(sig.bins)[1],"significant haplotype blocks"))
      }

      if(nrow(sug.snips) > 0)
      {
        sug.snips.list <- sug.snips
        sug.snips.list$trait <- traits[i]
        if(envs) sug.snips.list$env <- envs[q]
        sug.snips.save <- rbind(sug.snips.save,sug.snips.list)
        sug.bins <- merge(sug.snips,snpInfo,by.x="snp.id",by.y="SNP")
        sug.bins$RES <- abs(2*sug.bins$beta)/trait.range
        sug.bins <- sug.bins |> dplyr::group_by(hapID) |> dplyr::summarise(NSNP=length(pval),beta=max(beta),min_p=min(pval), RES=max(RES))
        sug.bins$trait <- traits[i]
        if(envs) sug.bins$env <- envs[q]
        sug.bins$pvalue <- "suggestive"
      } else {
        sug.bins$trait<-NULL
        sug.bins$env<-NULL
        sug.bins$pvalue<-NULL
      }

      sug.bins <- sug.bins[!sug.bins$hapID%in%sig.bins$hapID, ]
      print(paste(dim(sug.bins)[1],"suggestive haplotype blocks"))

      sig.blocks<-rbind(sig.blocks,sig.bins)
      sug.blocks<-rbind(sug.blocks,sug.bins)


    }
  }

  sig.snips <- unique(sig.snips.save,by="snp.id")
  sug.snips <- unique(sug.snips.save,by="snp.id")

  write.table <- write.table(sig.snips.save, get_project_dir(subdir = "Tables/Blocks/",file = "signif_snps_alltraits.txt"),sep="\t", row.names=FALSE, col.names=TRUE)
  write.table <- write.table(sug.snips.save, get_project_dir(subdir = "Tables/Blocks/",file = "suggestive_snps_alltraits.txt"),sep="\t", row.names=FALSE, col.names=TRUE)

  exclude <- results[!snpInfo$SNP %in% sig.snips$snp.id,]
  exclude_sug <- results[!snpInfo$SNP %in% sug.snips$snp.id,]
  write.table <- write.table(exclude$snp.id, get_project_dir(subdir = "Tables/Blocks/",file = "snps_NOT_in_sig_blocks.txt"),sep="\t", row.names=FALSE, col.names=TRUE,quote = FALSE)
  write.table <- write.table(exclude_sug$snp.id, get_project_dir(subdir = "Tables/Blocks/",file = "snps_NOT_in_sug_blocks.txt"),sep="\t", row.names=FALSE, col.names=TRUE,quote = FALSE)

  plink <- get_plink()
  SAM <- get_bim_data()
  blocks <- get_project_dir(subdir = "Tables/Blocks/",file = "snps_NOT_in_sig_blocks.txt")
  re_sig_blocks <- get_project_dir(subdir = "Tables/Blocks/",file = "re_sig_blocks")
  ldtable <- get_project_dir(subdir = "Tables/Blocks/",file = "ldtable")

  system(paste(plink," --bfile ",SAM," --exclude ",blocks," --blocks no-pheno-req no-small-max-span --blocks-max-kb 2000000 --blocks-strong-lowci 0.7005 --out ",re_sig_blocks," --allow-extra-chr --blocks-inform-frac 0.9",sep = ""))

  sug_blocks <- get_project_dir(subdir = "Tables/Blocks/",file = "snps_NOT_in_sug_blocks.txt")
  re_sug_blocks <- get_project_dir(subdir = "Tables/Blocks/",file = "re_sug_blocks")
  ldtable_sug <- get_project_dir(subdir = "Tables/Blocks/",file = "ldtable_sug")
  system(paste(plink," --bfile ",SAM," --exclude ",sug_blocks," --blocks no-pheno-req no-small-max-span --blocks-max-kb 2000000 --blocks-strong-lowci 0.7005 --out ",re_sug_blocks," --allow-extra-chr --blocks-inform-frac 0.9",sep = ""))

  ##### generate block id for snips
  re_sig_blocks <- get_project_dir(subdir = "Tables/Blocks/",file = "re_sig_blocks.blocks.det")
  if(file.exists(re_sig_blocks)) new.sig.blocks <- data.table::fread(re_sig_blocks) else stop("re_sig_blocks.det not found.")

  re_sug_blocks <- get_project_dir(subdir = "Tables/Blocks/",file = "re_sug_blocks.blocks.det")
  if(file.exists(re_sug_blocks)) new.sug.blocks <- data.table::fread(re_sug_blocks) else stop("re_sug_blocks.det not found.")

  if (dim(new.sig.blocks)[1]>0) {
    new.sig.blocks$Chr_num <- as.integer(gsub("Ha412HOChr","",new.sig.blocks$CHR))
    new.sig.blocks<- new.sig.blocks |> dplyr::group_by(Chr_num) |> dplyr::mutate(hapID = paste(Chr_num,c(1:length(Chr_num)),sep="_"))
    snps<-strsplit(new.sig.blocks$SNPS,split="|",fixed=T)
    sig.list<-unlist(snps)
    sig.list<-data.table::data.table(SNP=sig.list)
    sig.list$hapID<-c(rep(new.sig.blocks$hapID, new.sig.blocks$NSNPS))
    rm(snps)
  } else {sig.list<-data.frame(SNP=c(),hapID=c())} ## for when there are zero blocks

  if (dim(new.sug.blocks)[1]>0) {
    new.sug.blocks$Chr_num <- as.integer(gsub("Ha412HOChr","",new.sug.blocks$CHR))
    new.sug.blocks<- new.sug.blocks |> dplyr::group_by(Chr_num) |> dplyr::mutate(hapID = paste(Chr_num,c(1:length(Chr_num)),sep="_"))
    snps<-strsplit(new.sug.blocks$SNPS,split="|",fixed=T)
    sug.list<-unlist(snps)
    sug.list<-data.table::data.table(SNP=sug.list)
    sug.list$hapID<-c(rep(new.sug.blocks$hapID, new.sug.blocks$NSNPS))
    rm(snps)
  } else {sug.list<-data.frame(SNP=c(),hapID=c())} ## for when there are zero blocks

  ##### add in in singletons for significant snps
  missing.snps<-sig.snips[!sig.snips$snp.id%in%sig.list$SNP, ]
  missing.snps$Chr_num<- as.integer(gsub("Ha412HOChr","",missing.snps$chr))
  missing.snps<- missing.snps |> dplyr::group_by(Chr_num) |> dplyr::mutate(hapID=paste(Chr_num,"_single-sig",match(snp.id,unique(snp.id)),sep=""))
  missing.snps<-missing.snps[,c("snp.id","hapID")]
  names(missing.snps)<-c("SNP","hapID")

  sig.list<-rbind(sig.list,missing.snps)


  missing.snps.sug<-sug.snips[!sug.snips$snp.id%in%sug.list$SNP, ]
  missing.snps.sug$Chr_num<- as.integer(gsub("Ha412HOChr","",missing.snps.sug$chr))
  missing.snps.sug<- missing.snps.sug |> dplyr::group_by(Chr_num) |> dplyr::mutate(hapID=paste(Chr_num,"_single-sug",match(snp.id,unique(snp.id)),sep=""))
  missing.snps.sug<-missing.snps.sug[,c("snp.id","hapID")]
  names(missing.snps.sug)<-c("SNP","hapID")

  sug.list<-rbind(sug.list,missing.snps.sug)



  ### split SNP name into info
  sig.list$chr <- gsub("Ha412HOChr","",sig.list$SNP)
  sig.list$chr <- as.integer(gsub(":.*","",sig.list$chr))
  sig.list$ps <- as.integer(gsub(".*:","",sig.list$SNP))

  sig.list<-sig.list[order(sig.list$chr,sig.list$ps),]


  sug.list$chr <- gsub("Ha412HOChr","",sug.list$SNP)
  sug.list$chr <- as.integer(gsub(":.*","",sug.list$chr))
  sug.list$ps <- as.integer(gsub(".*:","",sug.list$SNP))
  sug.list<-sug.list[order(sug.list$chr,sug.list$ps),]


  #### add big haplotype block id's
  sig.list$sigblock_hapID<-sig.list$hapID
  sig.list$hapID<-NULL

  sig.list$hapID<-snpInfo$hapID[match(sig.list$SNP,snpInfo$SNP)]

  sig.list<-sig.list[order(sig.list$chr,sig.list$ps), ] ## order

  sig.list$sigblock_hapID<-forcats::fct_inorder(sig.list$sigblock_hapID)



  sug.list$sugblock_hapID<-sug.list$hapID
  sug.list$hapID<-NULL

  sug.list$hapID<-snpInfo$hapID[match(sug.list$SNP,snpInfo$SNP)]

  sug.list<-sug.list[order(sug.list$chr,sug.list$ps), ] ## order

  sug.list$sugblock_hapID<-forcats::fct_inorder(sug.list$sugblock_hapID)


  #### flag haplotype blocks that have been split in the new blocking instead of combined fully
  split.blocks<-sig.list |> dplyr::group_by(hapID) |> dplyr::summarize(blocks=length(unique(sigblock_hapID))) |> dplyr::filter(blocks>1)

  split.blocks.sug<-sug.list |> dplyr::group_by(hapID) |> dplyr::summarize(blocks=length(unique(sugblock_hapID))) |> dplyr::filter(blocks>1)


  ### keep full genome haplotype block when the block isn't fully merged with another
  sig.list$sigblock_hapID<-as.character(sig.list$sigblock_hapID)
  sig.list$sigblock_hapID[sig.list$hapID%in%split.blocks$hapID]<-paste(as.character(sig.list$hapID)[sig.list$hapID%in%split.blocks$hapID],"kept")

  sig.list$sigblock_hapID<-forcats::fct_inorder(sig.list$sigblock_hapID)



  sug.list$sugblock_hapID<-as.character(sug.list$sugblock_hapID)
  sug.list$sugblock_hapID[sug.list$hapID%in%split.blocks$hapID]<-paste(as.character(sug.list$hapID)[sug.list$hapID%in%split.blocks$hapID],"kept")

  sug.list$sugblock_hapID<-forcats::fct_inorder(sug.list$sugblock_hapID)

  #### pretty new block name
  sig.list<-sig.list |> dplyr::group_by(chr) |>
    dplyr::mutate(region=paste(formatC(as.numeric(chr),width=2, flag="0"),
                               formatC(as.numeric(factor(rank(match(sigblock_hapID,levels(sigblock_hapID))))),width=2, flag="0"),sep="-")) # super janky ordering
  sug.list<-sug.list |> dplyr::group_by(chr) |>
    dplyr::mutate(region=paste(formatC(as.numeric(chr),width=2, flag="0"),
                               formatC(as.numeric(factor(rank(match(sugblock_hapID,levels(sugblock_hapID))))),width=2, flag="0"),sep="-")) # super janky ordering

  #### add new (combined) block name to significant blocks data
  sighap_to_genomehap<-data.frame(genome.hap=unique(sig.list$hapID))
  sighap_to_genomehap$sig.hap<-sig.list$sigblock_hapID[match(sighap_to_genomehap$genome.hap,sig.list$hapID)]
  sighap_to_genomehap$colocate.region<-sig.list$region[match(sighap_to_genomehap$genome.hap,sig.list$hapID)]


  sughap_to_genomehap<-data.frame(genome.hap=unique(sug.list$hapID))
  sughap_to_genomehap$sug.hap<-sug.list$sugblock_hapID[match(sughap_to_genomehap$genome.hap,sug.list$hapID)]
  sughap_to_genomehap$colocate.region<-sug.list$region[match(sughap_to_genomehap$genome.hap,sug.list$hapID)]


  ### save some of the blocks objects for later
  # blocks_path <- get_project_dir(subdir = "Tables/Blocks/")
  write.table(sig.blocks, get_project_dir(subdir = "Tables/Blocks",file = "traits_to_genomeblocks_signif.txt"), sep="\t", row.names=F, col.names=T)
  write.table(sug.blocks, get_project_dir(subdir = "Tables/Blocks",file = "traits_to_genomeblocks_suggest.txt"), sep="\t", row.names=F, col.names=T)
  write.table(sig.list, get_project_dir(subdir = "Tables/Blocks",file = "sigsnips_to_genomeblocks.txt"), sep="\t", row.names=F, col.names=T)
  write.table(sighap_to_genomehap, get_project_dir(subdir = "Tables/Blocks",file = "condensed_genome_blocks.txt"), sep="\t", row.names=F, col.names=T)

  write.table(sug.list, get_project_dir(subdir = "Tables/Blocks",file = "sugsnips_to_genomeblocks.txt"), sep="\t", row.names=F, col.names=T)
  write.table(sughap_to_genomehap, get_project_dir(subdir = "Tables/Blocks",file = "sug_condensed_genome_blocks.txt"), sep="\t", row.names=F, col.names=T)

  #### calculate LD (D prime) for significant snps
  system(paste(plink," --bfile ",SAM," --exclude ",blocks," --r2 dprime yes-really --ld-window-kb 2000000 --ld-window-r2 0.0 --ld-window 1000 --out ",ldtable," --allow-extra-chr",sep = ""))

  ld.table<-data.table::fread(paste(ldtable,".ld",sep = ""))


  system(paste(plink," --bfile ",SAM," --exclude ",sug_blocks," --r2 dprime yes-really --ld-window-kb 2000000 --ld-window-r2 0.0 --ld-window 1000 --out ",ldtable_sug," --allow-extra-chr",sep = ""))

  # ld.table.sug<-data.table::fread(paste(ldtable_sug,".ld",sep = ""))


  ### plot new blocks and ld

  for (i in 1:length(unique(ld.table$CHR_A))) {
    chrom<-ld.table[ld.table$CHR_A==unique(ld.table$CHR_A)[i],]

    Chr.num<-as.numeric(gsub("Ha412HOChr","",unique(ld.table$CHR_A)[i]))

    chrom.snps<-unique(c(as.character(chrom$BP_A),as.character(chrom$BP_B)))
    nsnps<-length(chrom.snps)[1]

    chrom.snps<-data.table::data.table(BP_A=as.numeric(chrom.snps),BP_B=as.numeric(chrom.snps))

    chrom<-rbind(chrom,chrom.snps,fill=T)

    chrom$bp_A<-forcats::fct_reorder(factor(chrom$BP_A),chrom$BP_A)
    chrom$bp_B<-forcats::fct_reorder(factor(chrom$BP_B),chrom$BP_B)


    ## draw LD plot
    plot<-ggplot2::ggplot(data=chrom,ggplot2::aes(y=bp_A, x=bp_B,fill=R2))+ggplot2::geom_tile()+ggplot2::scale_fill_gradient(low = "white", high = "#E64A19",na.value = "black")+
      ggplot2::annotate(geom="polygon",x=c(0,0,nsnps+1), y=c(0,nsnps+1,nsnps+1),fill="white")+ggplot2::scale_y_discrete(position = "right")+
      ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1),axis.text.y = ggplot2::element_text(angle = 45, hjust = 1),
                     axis.title.x = ggplot2::element_blank(),axis.title.y = ggplot2::element_blank())


    ## get blocks info for the snps
    chrom.blocks<-data.frame(bp=unique(chrom$BP_A))
    chrom.blocks$SNP<-paste("Ha412HOChr",formatC(Chr.num,width=2,flag="0"),":",chrom.blocks$bp, sep="")
    chrom.blocks$big.hap<-forcats::fct_inorder(sig.list$hapID[match(chrom.blocks$SNP,sig.list$SNP)])
    chrom.blocks$sig.hap<-forcats::fct_inorder(as.character(sig.list$sigblock_hapID[match(chrom.blocks$SNP,sig.list$SNP)]))
    chrom.blocks$colocate.region<-sig.list$region[match(chrom.blocks$SNP,sig.list$SNP)]

    #### add block info to the ld plot
    colours<-rep(c(RColorBrewer::brewer.pal(8,"Dark2"))[-7],100)
    chrom.blocks$big.hap.colors<-colours[as.numeric(chrom.blocks$big.hap)]
    chrom.blocks$sig.hap.colors<-colours[as.numeric(chrom.blocks$sig.hap)]

    a<-0.2*(length(chrom.blocks$SNP)/10)*sin(45*pi/180)
    b<-0.2*(length(chrom.blocks$SNP)/10)*cos(45*pi/180)
    c<-0.5*(length(chrom.blocks$SNP)/10)*sin(45*pi/180)
    d<-0.5*(length(chrom.blocks$SNP)/10)*cos(45*pi/180)

    xbase<-c(rep(c(0:(length(chrom.blocks$SNP)-1)),each=4))+c(0.5,0.5,1.5,1.5)
    x.adjust<-c(-b,-b-d,-b-d,-b)
    x2.adjust<-c(-b-d,-b-d-d,-b-d-d,-b-d)

    ybase<-c(rep(c(0:(length(chrom.blocks$SNP)-1)),each=4))+c(0.5,0.5,1.5,1.5)
    y.adjust<-c(a,a+c,a+c,a)
    y2.adjust<-c(a+c,a+c+c,a+c+c,a+c)

    xs<-xbase+x.adjust
    xs2<-xbase+x2.adjust

    ys<-ybase+y.adjust
    ys2<-ybase+y2.adjust
    group<-c(rep(c(0:(length(chrom.blocks$SNP)-1)),each=4))

    big.hap<-data.frame(xs,ys,group)
    sig.hap<-data.frame(xs2,ys2,group)

    sig.hap$colocate.region<-rep(chrom.blocks$colocate.region,each=4)

    test<-sig.hap |> dplyr::group_by(colocate.region) |> dplyr::summarize (x=mean(xs2),y=mean(ys2))

    hap.plot<-plot+ggplot2::geom_polygon(data=big.hap,ggplot2::aes(x=xs,y=ys,group=group),fill=rep(chrom.blocks$big.hap.colors,each=4))+
      ggplot2::geom_polygon(data=sig.hap,ggplot2::aes(x=xs2,y=ys2,group=group),fill=rep(chrom.blocks$sig.hap.colors,each=4))+
      ggplot2::geom_segment(x=xs2[1],y=ys2[1],xend=xs2[length(xs2)],yend=ys2[length(ys2)],col="black")+
      ggplot2::coord_fixed(xlim=c(0.5,(length(chrom.blocks$SNP)+0.5)*1.05),ylim=c(0.5-(length(chrom.blocks$SNP)+0.5)*0.05,length(chrom.blocks$SNP)+0.5),clip="off",expand=0)+
      ggplot2::theme(legend.position="none")+
      ggplot2::annotate("text", x=xs[1],y=ys[1],label="Genome ", angle=45,hjust=1,vjust=0)+
      ggplot2::annotate("text", x=xs2[1],y=ys2[1],label="Significant ", angle=45,hjust=1,vjust=0)
    # annotate("text",x=test$x,y=test$y,label=test$colocate.region, angle=45,hjust=0.5,vjust=0.5)


    hap.plot<-hap.plot+ggrepel::geom_text_repel(data=test,ggplot2::aes(x=x,y=y,label=colocate.region,group=NULL,fill=NULL),
                                                nudge_y=8*a,
                                                nudge_x=-b,
                                                direction="y",
                                                angle=45)

    # legend<-ggpubr::get_legend(plot)

    # plot_path <- paste(get_project_dir(),"Plots/Colocalization/",sep="")
    # if(!dir.exists(plot_path)) dir.create(plot_path,recursive = TRUE)
    pdf(get_project_dir(subdir = "Plots/Colocalization/",file = paste("Chromosome-",Chr.num,".pdf",sep = "")),height=7.5,width=10.5)

    # png(paste("Plots/Colocalization/Chromosome-",i,".png",sep=""),height=750,width=1050)

    grid::grid.newpage()

    grid::pushViewport(grid::viewport(name = "rotate", angle = -45, clip = "off", width = 0.9, height = 0.9))
    print(hap.plot, vp = "rotate")

    vp<-grid::viewport(x=0.28,y=0.8,width=0.4,height = 0.1)
    grid::pushViewport(vp)
    grid::grid.text(as.character(paste("chromosome:",Chr.num)), 0.2, 0.2,gp=grid::gpar(cex=1.5))
    grid::popViewport(1)

    vp<-grid::viewport(x=0.6,y=0.85,width=0.1,height = 0.1)
    grid::pushViewport(vp)
    grid::grid.draw(ggpubr::get_legend(plot))
    grid::popViewport(1)
    # popViewport(1)
    dev.off()

  }
}

