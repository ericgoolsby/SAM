#' @export
colocal <- function()
{
  colors<-c("#1b9e77", "gray85")
  sig.blocks <- read.table(get_project_dir(subdir = "Tables/Blocks/",file = "traits_to_genomeblocks_signif.txt"), sep="\t", header = TRUE)
  sig.list <- read.table(get_project_dir(subdir = "Tables/Blocks/",file = "sigsnips_to_genomeblocks.txt"), sep="\t", header=TRUE)
  sighap_to_genomehap <- read.table(get_project_dir(subdir = "Tables/Blocks/",file = "condensed_genome_blocks.txt"), sep="\t", header=TRUE)

  sug.blocks <- read.table(get_project_dir(subdir = "Tables/Blocks/",file = "traits_to_genomeblocks_suggest.txt"), sep="\t", header=TRUE)
  sug.list <- read.table(get_project_dir(subdir = "Tables/Blocks/",file = "sugsnips_to_genomeblocks.txt"), sep="\t", header=TRUE)
  sughap_to_genomehap <- read.table(get_project_dir(subdir = "Tables/Blocks/",file = "sug_condensed_genome_blocks.txt"), sep="\t", header=TRUE)


  #### set up data to feed into plotting
  colocate<-rbind(sig.blocks,sug.blocks[sug.blocks$hapID%in%sig.blocks$hapID,])
  colocate$sighap<-sighap_to_genomehap$sig.hap[match(colocate$hapID,sighap_to_genomehap$genome.hap)]
  colocate$region<-sighap_to_genomehap$colocate.region[match(colocate$hapID,sighap_to_genomehap$genome.hap)]
  colocate$trait_env<-paste(colocate$trait,colocate$env,sep="_")

  traits.per.block<-colocate |> dplyr::group_by(sighap) |> dplyr::summarize(trait_num=length(trait_env))

  colocate<-colocate |> tidyr::separate(sighap, sep= "_", c("chromosome","blocknum"),remove=F) |>
    dplyr::arrange(chromosome, blocknum)

  colocate<- colocate |> dplyr::mutate(beta.sign=sign(beta))

  colocate$region<-factor(colocate$region)
  colocate$env <- ""
  envs <- ""
  write.table(colocate,get_project_dir(subdir = "Tables/Blocks/","colocate_table.txt"))

  colocate_sug<-rbind(sug.blocks,sug.blocks[sug.blocks$hapID%in%sug.blocks$hapID,])
  colocate_sug$sughap<-sughap_to_genomehap$sug.hap[match(colocate_sug$hapID,sughap_to_genomehap$genome.hap)]
  colocate_sug$region<-sughap_to_genomehap$colocate.region[match(colocate_sug$hapID,sughap_to_genomehap$genome.hap)]
  colocate_sug$trait_env<-paste(colocate_sug$trait,colocate_sug$env,sep="_")

  traits.per.block<-colocate_sug |> dplyr::group_by(sughap) |> dplyr::summarize(trait_num=length(trait_env))

  colocate_sug<-colocate_sug |> tidyr::separate(sughap, sep= "_", c("chromosome","blocknum"),remove=F) |>
    dplyr::arrange(chromosome, blocknum)

  colocate_sug<- colocate_sug |> dplyr::mutate(beta.sign=sign(beta))

  colocate_sug$region<-factor(colocate_sug$region)
  colocate_sug$env <- ""
  envs <- ""
  write.table(colocate_sug,get_project_dir(subdir = "Tables/Blocks/","colocate_sug_table.txt"))


  gff3 <- data.table::fread(get_gff3())
  mrna <- gff3[gff3$type=="mRNA",]
  mrna$product <- urltools::url_decode(mrna$product)
  mrna$attributes <- NULL

  blocks <- data.table::fread(get_blocks()[1])
  blocks$Chr_num<- as.integer(gsub("Ha412HOChr","",blocks$CHR))
  blocks<- blocks |> dplyr::group_by(Chr_num) |> dplyr::mutate(hapID = paste(Chr_num,c(1:length(Chr_num)),sep="_"))
  snps<-strsplit(blocks$SNPS,split="|",fixed=T)
  big.list<-unlist(snps)
  big.list<-data.table::data.table(SNP=big.list)
  big.list$hapID<-c(rep(blocks$hapID, blocks$NSNPS))
  rm(snps)

  ### qd solution singletons
  all.snps<-data.table::fread(get_blocks()[2], header=F)
  names(all.snps)[1:4]<-c("chr","rs","V3","ps")
  all.snps$V3<-NULL

  missing.snps<-all.snps[!all.snps$rs%in%big.list$SNP,]
  missing.snps$Chr_num<- as.integer(gsub("Ha412HOChr","",missing.snps$chr))
  missing.snps<- missing.snps |> dplyr::group_by(Chr_num) |> dplyr::mutate(hapID=paste(Chr_num,"_single",match(rs,unique(rs)),sep=""))
  missing.snps<-missing.snps[,c(2,5)]
  names(missing.snps)<-c("SNP","hapID")

  big.list<-rbind(big.list,missing.snps)

  sig.list <- read.table(get_project_dir(subdir = "Tables/Blocks/",file = "sigsnips_to_genomeblocks.txt"), sep="\t", header=TRUE)
  genemap<-read.table(get_project_dir(subdir = "Tables/Blocks/",file = "condensed_genome_blocks.txt"), sep="\t", header=TRUE)
  colocate<-read.table(get_project_dir(subdir = "Tables/Blocks/",file = "colocate_table.txt"), sep="\t", header=TRUE)
  genemap$colocate.block<-genemap$colocate.region #rename
  sig.snips<-read.table(get_project_dir(subdir = "Tables/Blocks/","signif_snps_alltraits.txt"), sep="\t", header=TRUE)

  genemap$start<-blocks$BP1[match(genemap$genome.hap,blocks$hapID)]
  genemap$stop<-blocks$BP2[match(genemap$genome.hap,blocks$hapID)]
  genemap$chr<-blocks$CHR[match(genemap$genome.hap,blocks$hapID)]
  genemap$block.type<-"region"

  single.snps<-sig.list$SNP[match(genemap$genome.hap[is.na(genemap$start)],sig.list$hapID)]
  single.snps.ps<-sig.list$ps[match(genemap$genome.hap[is.na(genemap$start)],sig.list$hapID)]
  single.snps.chr<-paste("Ha412HOChr",formatC(sig.list$chr[match(genemap$genome.hap[is.na(genemap$start)],sig.list$hapID)],width =2,flag="0"),sep="")

  genemap$block.type[is.na(genemap$start)]<-"single"
  genemap$start[is.na(genemap$start)]<-single.snps.ps
  genemap$stop[is.na(genemap$stop)]<-single.snps.ps
  genemap$chr[is.na(genemap$chr)]<-single.snps.chr

  #### find genes in the genome haplotype blocks

  genemap$nr.genes<-NA

  gene.list<-NULL

  for (i in 1:length(genemap$genome.hap)) {
    print(paste("Chromosome:",genemap$chr[i],"Block ID:",genemap$genome.hap[i]))
    chrom.mrna<-mrna[mrna$seqid==genemap$chr[i],]

    if(sum(chrom.mrna$start>genemap$start[i]&chrom.mrna$end<genemap$stop[i])>0) {

      genemap$nr.genes[i]<-sum(chrom.mrna$start>genemap$start[i]&chrom.mrna$end<genemap$stop[i])
      block.mrna<-chrom.mrna[which((chrom.mrna$start>genemap$start[i]&chrom.mrna$end<genemap$stop[i])), ]
    }
    if(sum(chrom.mrna$start>genemap$start[i]&chrom.mrna$end<genemap$stop[i])==0) {
      single.snp.genes<-unique(c(dplyr::last(which(chrom.mrna$start<genemap$start[i])),
                                 dplyr::first(which(chrom.mrna$end>genemap$stop[i]))))
      genemap$nr.genes[i]<-length(single.snp.genes)
      block.mrna<-chrom.mrna[single.snp.genes, ]
    }
    block.mrna<-block.mrna[, c(4,5,12:18)] #remove info
    block.mrna$genome.hap<-genemap$genome.hap[i] # add genome.hap id
    block.mrna$chr<-genemap$chr[i]

    gene.list<-rbind(gene.list,block.mrna)  # merge together

  }

  #### wrangle with the significant snps haplotype blocks

  gene.list$sig.hap<-genemap$sig.hap[match(gene.list$genome.hap,genemap$genome.hap)]
  gene.list$colocate.block<-genemap$colocate.block[match(gene.list$genome.hap,genemap$genome.hap)]

  gene.list<-gene.list |> dplyr::group_by(colocate.block) |> dplyr::group_by (locus_tag) |> dplyr::slice(1) ## remove duplicate genes from singif snps block

  gene.list<-gene.list[,c(13,1:12)] #shuffle columns for saving


  ##### add traits for which the block is significant


  # genes_path <- paste(get_output_dir(),"Tables/Genes/",sep="")
  # if(!dir.exists(genes_path)) dir.create(genes_path,recursive = TRUE)

  write.csv(gene.list,get_project_dir(subdir = "Tables/Genes/",file = "genelist.csv"))

  ### plot region gene sizes

  gene.count<-gene.list |> dplyr::group_by(colocate.block,chr) |> dplyr::count(colocate.block)

  # colours <- c("#e6194b", "#3cb44b", "#ffe119", "#0082c8", "#f58231", "#911eb4",
  #              "#46f0f0", "#f032e6", "#d2f53c", "#fabebe", "#008080", "#e6beff",
  #              "#aa6e28", "#fffac8", "#800000", "#aaffc3", "#808000", "#ffd8b1",
  #              "#000080", "#808080")

  gene.count$CHR<-gsub("Ha412HOChr","",gene.count$chr)

  gene.count$colocate.block<-forcats::fct_rev(forcats::fct_reorder(gene.count$colocate.block, gene.count$n))

  # plotbase<-ggplot2::ggplot(gene.count,ggplot2::aes(x=colocate.block ,y=n, fill=CHR))
  # genes.plot<-plotbase+ggplot2::geom_point(shape=21,col="gray",size=2)+
  #   ggplot2::scale_y_continuous(trans='log10',breaks=c(1,2,3,4,5,10,50,100,500,1000))+
  #   ggplot2::theme_minimal()+
  #   ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 90, vjust=0.5,hjust = 1))+
  #   ggplot2::theme(legend.position="right")+ggplot2::guides(fill = ggplot2::guide_legend(ncol=1))+
  #   ggplot2::scale_fill_manual(values=colours,name="Chromosome")+
  #   ggplot2::xlab("significant region")+ggplot2::ylab("Number of genes (log10)")
  #
  # genes.plot
  #
  # plots_path <- paste(get_output_dir(),"Plots/Colocalization/",sep="")
  # if(!dir.exists(plots_path)) dir.create(plots_path,recursive = TRUE)
  #
  #
  # ggplot2::ggsave(paste(plots_path,"nr_genes.pdf",sep=""),genes.plot, width=18, height=10)
  write.csv(gene.count,get_project_dir(subdir = "Tables/Genes/",file = "genecount.csv"))

  colocate<-read.table(get_project_dir(subdir = "Tables/Blocks/",file = "colocate_table.txt"))
  region.PVE<-colocate |> dplyr::filter(pvalue=="significant") |>
    dplyr::group_by(trait_env,region) |> dplyr::summarise(PVE=max(RES))

  write.table(region.PVE,get_project_dir(subdir = "Tables/Blocks/",file = "PVE.txt"))

  # trait.PVE <- region.PVE |> dplyr::group_by(trait_env) |> dplyr::summarise(PVE=sum(PVE), count=length(region)) # |> tidyr::separate(trait_env,into=c("trait","env"),sep="_")
  # trait.PVE<-region.PVE |> dplyr::group_by(trait_env) |> dplyr::summarise(PVE=sum(PVE), count=length(region)) |> tidyr::separate(trait_env,into=c("trait","env"),sep="_")

  # PVE <- trait.PVE |> tidyr::gather("metric","value", -c(trait_env)) |> tidyr::unite("spreader",trait_env,metric,sep="_") |> tidyr::spread(spreader,value)

  # PVE<- trait.PVE |> tidyr::gather("metric","value", -c(trait,env)) |> tidyr::unite("spreader",env,metric,sep="_") |> tidyr::spread(spreader,value)

  # write.table(trait.PVE,get_project_dir(subdir = "Tables/Blocks/",file = "PVE.txt"))


  print("Significant SNPs completed successfully.")
































  sug.list <- read.table(get_project_dir(subdir = "Tables/Blocks/",file = "sugsnips_to_genomeblocks.txt"), sep="\t", header=TRUE)
  sug_genemap<-read.table(get_project_dir(subdir = "Tables/Blocks/",file = "sug_condensed_genome_blocks.txt"), sep="\t", header=TRUE)
  colocate_sug<-read.table(get_project_dir(subdir = "Tables/Blocks/",file = "colocate_sug_table.txt"), sep="\t", header=TRUE)
  sug_genemap$colocate.block<-sug_genemap$colocate.region #rename
  sug.snips<-read.table(get_project_dir(subdir = "Tables/Blocks/","suggestive_snps_alltraits.txt"), sep="\t", header=TRUE)



  sug_genemap$start<-blocks$BP1[match(sug_genemap$genome.hap,blocks$hapID)]
  sug_genemap$stop<-blocks$BP2[match(sug_genemap$genome.hap,blocks$hapID)]
  sug_genemap$chr<-blocks$CHR[match(sug_genemap$genome.hap,blocks$hapID)]
  sug_genemap$block.type<-"region"

  sug_single.snps<-sug.list$SNP[match(sug_genemap$genome.hap[is.na(sug_genemap$start)],sug.list$hapID)]
  sug_single.snps.ps<-sug.list$ps[match(sug_genemap$genome.hap[is.na(sug_genemap$start)],sug.list$hapID)]
  sug_single.snps.chr<-paste("Ha412HOChr",formatC(sug.list$chr[match(sug_genemap$genome.hap[is.na(sug_genemap$start)],sug.list$hapID)],width =2,flag="0"),sep="")

  sug_genemap$block.type[is.na(sug_genemap$start)]<-"single"
  sug_genemap$start[is.na(sug_genemap$start)]<-sug_single.snps.ps
  sug_genemap$stop[is.na(sug_genemap$stop)]<-sug_single.snps.ps
  sug_genemap$chr[is.na(sug_genemap$chr)]<-sug_single.snps.chr

  #### find genes in the genome haplotype blocks

  sug_genemap$nr.genes<-NA

  sug_gene.list<-NULL

  for (i in 1:length(sug_genemap$genome.hap)) {
    print(paste("Chromosome:",sug_genemap$chr[i],"Block ID:",sug_genemap$genome.hap[i]))
    chrom.mrna<-mrna[mrna$seqid==sug_genemap$chr[i],]

    if(sum(chrom.mrna$start>sug_genemap$start[i]&chrom.mrna$end<sug_genemap$stop[i])>0) {

      sug_genemap$nr.genes[i]<-sum(chrom.mrna$start>sug_genemap$start[i]&chrom.mrna$end<sug_genemap$stop[i])
      block.mrna<-chrom.mrna[which((chrom.mrna$start>sug_genemap$start[i]&chrom.mrna$end<sug_genemap$stop[i])), ]
    }
    if(sum(chrom.mrna$start>sug_genemap$start[i]&chrom.mrna$end<sug_genemap$stop[i])==0) {
      single.snp.genes<-unique(c(dplyr::last(which(chrom.mrna$start<sug_genemap$start[i])),
                                 dplyr::first(which(chrom.mrna$end>sug_genemap$stop[i]))))
      sug_genemap$nr.genes[i]<-length(single.snp.genes)
      block.mrna<-chrom.mrna[single.snp.genes, ]
    }
    block.mrna<-block.mrna[, c(4,5,12:18)] #remove info
    block.mrna$genome.hap<-sug_genemap$genome.hap[i] # add genome.hap id
    block.mrna$chr<-sug_genemap$chr[i]

    sug_gene.list<-rbind(sug_gene.list,block.mrna)  # merge together

  }

  #### wrangle with the suggestive snps haplotype blocks

  sug_gene.list$sug.hap<-sug_genemap$sug.hap[match(sug_gene.list$genome.hap,sug_genemap$genome.hap)]
  sug_gene.list$colocate.block<-sug_genemap$colocate.block[match(sug_gene.list$genome.hap,sug_genemap$genome.hap)]

  sug_gene.list<-sug_gene.list |> dplyr::group_by(colocate.block) |> dplyr::group_by (locus_tag) |> dplyr::slice(1) ## remove duplicate genes from singif snps block

  sug_gene.list<-sug_gene.list[,c(13,1:12)] #shuffle columns for saving


  ##### add traits for which the block is suggestive


  # genes_path <- paste(get_output_dir(),"Tables/Genes/",sep="")
  # if(!dir.exists(genes_path)) dir.create(genes_path,recursive = TRUE)

  write.csv(sug_gene.list,get_project_dir(subdir = "Tables/Genes/",file = "genelist_sug.csv"))

  ### plot region gene sizes

  sug_gene.count<-sug_gene.list |> dplyr::group_by(colocate.block,chr) |> dplyr::count(colocate.block)

  # colours <- c("#e6194b", "#3cb44b", "#ffe119", "#0082c8", "#f58231", "#911eb4",
  #              "#46f0f0", "#f032e6", "#d2f53c", "#fabebe", "#008080", "#e6beff",
  #              "#aa6e28", "#fffac8", "#800000", "#aaffc3", "#808000", "#ffd8b1",
  #              "#000080", "#808080")

  sug_gene.count$CHR<-gsub("Ha412HOChr","",sug_gene.count$chr)

  sug_gene.count$colocate.block<-forcats::fct_rev(forcats::fct_reorder(sug_gene.count$colocate.block, sug_gene.count$n))

  # plotbase<-ggplot2::ggplot(sug_gene.count,ggplot2::aes(x=colocate.block ,y=n, fill=CHR))
  # genes.plot<-plotbase+ggplot2::geom_point(shape=21,col="gray",size=2)+
  #   ggplot2::scale_y_continuous(trans='log10',breaks=c(1,2,3,4,5,10,50,100,500,1000))+
  #   ggplot2::theme_minimal()+
  #   ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 90, vjust=0.5,hjust = 1))+
  #   ggplot2::theme(legend.position="right")+ggplot2::guides(fill = ggplot2::guide_legend(ncol=1))+
  #   ggplot2::scale_fill_manual(values=colours,name="Chromosome")+
  #   ggplot2::xlab("suggestive region")+ggplot2::ylab("Number of genes (log10)")
  #
  # genes.plot
  #
  # plots_path <- paste(get_output_dir(),"Plots/Colocalization/",sep="")
  # if(!dir.exists(plots_path)) dir.create(plots_path,recursive = TRUE)
  #
  #
  # ggplot2::ggsave(paste(plots_path,"nr_genes.pdf",sep=""),genes.plot, width=18, height=10)
  write.csv(sug_gene.count,get_project_dir(subdir = "Tables/Genes/",file = "sug_genecount.csv"))

  colocate_sug<-read.table(get_project_dir(subdir = "Tables/Blocks/",file = "colocate_sug_table.txt"))
  region.PVE <- colocate_sug |> dplyr::filter(pvalue=="suggestive") |>
    dplyr::group_by(trait_env,region) |> dplyr::summarise(PVE=max(RES))

  # region.PVE<-colocate_sug |> dplyr::filter(pvalue=="suggestive") |>
  #   dplyr::group_by(trait_env,region) |> dplyr::summarise(PVE=max(RES))

  write.table(region.PVE,get_project_dir(subdir = "Tables/Blocks/",file = "PVE_sug.txt"))

  # trait.PVE <- region.PVE |> dplyr::group_by(trait_env) |> dplyr::summarise(PVE=sum(PVE), count=length(region))

  # trait.PVE<-region.PVE |> dplyr::group_by(trait_env) |> dplyr::summarise(PVE=sum(PVE), count=length(region)) |> tidyr::separate(trait_env,into=c("trait","env"),sep="_")

  # PVE<-trait.PVE |> tidyr::gather("metric","value", -c(trait,env)) |> tidyr::unite("spreader",env,metric,sep="_") |> tidyr::spread(spreader,value)

  # write.table(PVE,get_project_dir(subdir = "Tables/Blocks/",file = "PVE_sug.txt"))


  print("Suggestive SNPs completed successfully.")
}
