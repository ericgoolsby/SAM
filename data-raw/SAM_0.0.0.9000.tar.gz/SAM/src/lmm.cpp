#include <RcppEigen.h>
#include <Eigen/StdVector>

// [[Rcpp::depends(RcppEigen)]]

using namespace Rcpp;

// [[Rcpp::export]]
double lmm_gradient_logl(const Eigen::Map<Eigen::MatrixXd>& X,const Eigen::Map<Eigen::VectorXd>& Y,const Eigen::Map<Eigen::MatrixXd>& K,double logd,double n,double p,double REML,
                            double h,
                            Eigen::Map<Eigen::MatrixXd>& Xstar,
                            Eigen::Map<Eigen::VectorXd>& Ystar,
                            Eigen::Map<Eigen::MatrixXd>& XX,
                            Eigen::Map<Eigen::VectorXd>& XY,
                            Eigen::Map<Eigen::VectorXd>& B,
                            Eigen::Map<Eigen::MatrixXd>& V,
                            Eigen::Map<Eigen::MatrixXd>& cholV,
                            Eigen::Map<Eigen::MatrixXd>& XXinv,
                            int ret_logl = 0,double sig2 = 1)
{
  V = K*h;
  V.diagonal().array() += (1-h);
  Eigen::LLT<Eigen::MatrixXd> lltV(V);
  cholV = lltV.matrixL();
  Eigen::MatrixXd Im = Eigen::MatrixXd::Identity(n,n);

  logd = 2.0 * cholV.diagonal().array().log().sum();

  Xstar = cholV.triangularView<Eigen::Lower>().solve(X);
  Ystar = cholV.triangularView<Eigen::Lower>().solve(Y);
  XX = Xstar.transpose()*Xstar;
  XY = Xstar.transpose()*Ystar;
  double YY = Ystar.dot(Ystar);
  B = XX.ldlt().solve(XY);
  double rss = YY - 2*B.transpose()*XY + B.transpose()*XX*B;
  if(sig2 == 1)
  {
    sig2 = rss/(n-REML*p);
  }
  double logDetXX = 2.0 * XX.llt().matrixL().toDenseMatrix().diagonal().array().log().sum() - std::log(sig2)*p;
  double ll = -.5*((n-REML*p)*std::log(2*M_PI) + logd + n*std::log(sig2) + REML*logDetXX + rss/sig2);

  if(ret_logl == 1)
  {
    return(ll);
  }

  XX /= sig2;
  Eigen::MatrixXd Ip = Eigen::MatrixXd::Identity(XX.rows(), XX.cols());
  XXinv = XX.llt().solve(Ip);
  if(ret_logl == 2)
  {
    return(sig2);
  }

  double sqrt_sig2 = std::sqrt(sig2);
  cholV *= sqrt_sig2;
  Ystar /= sqrt_sig2;
  Xstar /= sqrt_sig2;
  YY /= sig2;
  XY /= sig2;
  Eigen::VectorXd YstarXB = Ystar-Xstar*B;

  Eigen::MatrixXd cholVinv = cholV.triangularView<Eigen::Lower>().solve(Im);
  Eigen::MatrixXd tcholVinv = cholVinv.transpose();

  Eigen::MatrixXd cholVinv_kmat = cholVinv * K;
  Eigen::MatrixXd kmat_Winv = tcholVinv * cholVinv_kmat;
  double tr_dlogdetW = sig2*(tcholVinv * cholVinv).diagonal().sum()/2 - sig2*kmat_Winv.diagonal().sum()/2;
  Eigen::MatrixXd kmat_Winv_X = cholVinv_kmat.transpose() * Xstar;
  Eigen::MatrixXd cholVinv_Xstar = tcholVinv * Xstar;

  double tr_dlogdetXX = sig2*(kmat_Winv_X.transpose() * cholVinv_Xstar * XXinv).diagonal().sum()/2 -
    sig2*(cholVinv_Xstar.transpose() * cholVinv_Xstar * XXinv).diagonal().sum()/2;

  Eigen::MatrixXd YstarXB_Winv_kmat = cholVinv_kmat.transpose() * YstarXB;
  Eigen::MatrixXd cholVinv_YstarXB = tcholVinv * YstarXB;
  Eigen::MatrixXd cholVinv_YstarXB_Winv_kmat = cholVinv * YstarXB_Winv_kmat;
  double dYXB_Winv_YXB = sig2*(cholVinv_YstarXB_Winv_kmat.transpose() * YstarXB).coeff(0,0) / 2 - sig2*(cholVinv_YstarXB.transpose()*cholVinv_YstarXB).coeff(0,0)/2;

  double gradi = dYXB_Winv_YXB + tr_dlogdetW + tr_dlogdetXX;
  return(gradi);
}

// [[Rcpp::export]]
double lmm_fit(const Eigen::Map<Eigen::MatrixXd>& X,const Eigen::Map<Eigen::VectorXd>& Y,const Eigen::Map<Eigen::MatrixXd>& cholV,double logd,double n,double p,double REML,
                       Eigen::Map<Eigen::MatrixXd>& Xstar,
                       Eigen::Map<Eigen::VectorXd>& Ystar,
                       Eigen::Map<Eigen::MatrixXd>& XX,
                       Eigen::Map<Eigen::VectorXd>& XY,
                       Eigen::Map<Eigen::VectorXd>& B)
{
  Xstar = cholV.triangularView<Eigen::Lower>().solve(X);
  Ystar = cholV.triangularView<Eigen::Lower>().solve(Y);
  XX = Xstar.transpose()*Xstar;
  XY = Xstar.transpose()*Ystar;
  double YY = Ystar.dot(Ystar);
  B = XX.ldlt().solve(XY);
  double rss = YY - 2*B.transpose()*XY + B.transpose()*XX*B;
  double sig2 = rss/(n-REML*p);
  double logDetXX = 2.0 * XX.llt().matrixL().toDenseMatrix().diagonal().array().log().sum() - std::log(sig2)*p;
  double ll = -.5*((n-REML*p)*std::log(2*M_PI) + logd + n*std::log(sig2) + REML*logDetXX + rss/sig2);
  return(ll);
}


//' Multi-fit lmm
//'
//' Description here
//'
//' @param x A numeric vector of values.
//' @export
// [[Rcpp::export]]
void lmm_fit_multi(const Eigen::Map<Eigen::MatrixXd>& X,const Eigen::Map<Eigen::VectorXd>& Y,
                           const Rcpp::List& cholVs,
                           const Eigen::Map<Eigen::VectorXd>& logds, double n,double p,double REML,
                           Eigen::Map<Eigen::MatrixXd>& cholV,
                           Eigen::Map<Eigen::MatrixXd>& Xstar,
                           Eigen::Map<Eigen::VectorXd>& Ystar,
                           Eigen::Map<Eigen::MatrixXd>& XX,
                           Eigen::Map<Eigen::VectorXd>& XY,
                           Eigen::Map<Eigen::VectorXd>& sig2,
                           Eigen::Map<Eigen::VectorXd>& B,
                           Eigen::Map<Eigen::VectorXd>& Bhat,
                           Eigen::Map<Eigen::MatrixXd>& XXhat,
                           Eigen::Map<Eigen::VectorXd>& logLiks)
{
  int m = cholVs.size();
  double maxlogLik;
  double logDetXX = 0;
  p *= REML; // sets p to zero if REML is zero
  for(int i = 0; i < m; i++) {
    cholV = Rcpp::as<Eigen::Map<Eigen::MatrixXd> >(cholVs[i]);
    Xstar = cholV.triangularView<Eigen::Lower>().solve(X);
    Ystar = cholV.triangularView<Eigen::Lower>().solve(Y);
    XX = Xstar.transpose()*Xstar;
    XY = Xstar.transpose()*Ystar;
    double YY = Ystar.dot(Ystar);
    B = XX.ldlt().solve(XY);
    double rss = YY - 2*B.transpose()*XY + B.transpose()*XX*B;
    sig2[i] = rss/(n-p);
    if(REML == 1)
    {
      logDetXX = 2.0 * XX.llt().matrixL().toDenseMatrix().diagonal().array().log().sum() - std::log(sig2[i])*p;
    }
    double ll = -.5*((n-p)*std::log(2*M_PI) + logds[i] + n*std::log(sig2[i]) + logDetXX + rss/sig2[i]);
    logLiks[i] = ll;
    if(i==1){
      maxlogLik = ll;
      XXhat = XX;
      Bhat = B;
    } else if(ll > maxlogLik) {
      maxlogLik = ll;
      XXhat = XX;
      Bhat = B;
    }
  }
}
